#ifndef ANALIZADORP0_SISTEMAENTRADA_H
#define ANALIZADORP0_SISTEMAENTRADA_H
#endif


void inicializarSistemaEntrada(char * nombreFichero);
char siguienteChar();
void finalizarSistemaEntrada();
char * getLexemaCompleto(int aceptacionPorSigChar);
void finLexema();