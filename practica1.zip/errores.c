#include <stdio.h>
#include "errores.h"

void errorTamanoLexema(){
    fprintf(stdout, "Error: Tamano del lexema supera el limite máximo\n");
}
