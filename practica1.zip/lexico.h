#ifndef LEXICO_H
#define LEXICO_H

#include "ts.h"

compLexico siguienteComponente();

#endif