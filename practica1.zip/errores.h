#ifndef ANALIZADORP0_ERRORES_H
#define ANALIZADORP0_ERRORES_H



void errorTamanoLexema();


#endif //ANALIZADORP0_ERRORES_H
